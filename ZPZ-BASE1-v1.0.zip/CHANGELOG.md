# Changelog

## [1.0.0] - 2025-07-11
- Initial release of ZPZ Base 1 by Yuiko
- DNS Lookup
- WHOIS Lookup
- GeoIP Lookup
- Port Scanner (multi-thread)
- Subdomain Finder (with passive brute-force)
